﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconHunter
{
    class AsciiArt
    {
        public static void BeaconHunter_AsciiArt()

        {

            
            Console.WriteLine("\n ░█▀▄░█▀▀░█▀█░█▀▀░█▀█░█▀█░█░█░█░█░█▀█░▀█▀░█▀▀░█▀▄");
            Console.WriteLine(" ░█▀▄░█▀▀░█▀█░█░░░█░█░█░█░█▀█░█░█░█░█░░█░░█▀▀░█▀▄");
            Console.WriteLine(" ░▀▀░░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀░▀░▀▀▀░▀░▀░░▀░░▀▀▀░▀░▀");
            Console.WriteLine(" \n Author: Andrew Oliveau");


        }
    }
}
